// // Dark Mode Toggle
// const themeToggle = document.getElementById('theme-toggle');
// themeToggle.addEventListener('change', () => {
//     document.body.classList.toggle('dark-mode');
// });

// // Typing Effect
// document.addEventListener("DOMContentLoaded", function() {
//     const textElement = document.getElementById("typing-text");
//     textElement.style.width = "100%";
// });



document.addEventListener("DOMContentLoaded", function() {
    const darkModeToggle = document.getElementById("darkModeToggle");
    const hamburger = document.getElementById("hamburger");
    const navLinks = document.getElementById("nav-links");

    // Theme Toggle Functionality
    darkModeToggle.addEventListener("change", function() {
        document.body.classList.toggle("dark-mode", this.checked);
    });

    // Hamburger Menu Toggle
    hamburger.addEventListener("click", function() {
        navLinks.classList.toggle("active");
    });

    // Close menu when a link is clicked (for mobile devices)
    document.querySelectorAll(".nav-links a").forEach(link => {
        link.addEventListener("click", () => {
            navLinks.classList.remove("active");
        });
    });
});


function adjustGrid() {
    const taskContainer = document.querySelector(".tasks");

    if (window.innerWidth <= 768) {
        taskContainer.style.gridTemplateColumns = "1fr"; // 1 card per row
    } else {
        taskContainer.style.gridTemplateColumns = "repeat(2, 1fr)"; // 2 cards per row
    }
}

// Adjust on page load and window resize
window.addEventListener("load", adjustGrid);
window.addEventListener("resize", adjustGrid);
